function getRandomColor() {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

// 生成随机验证码（4位）
function generateCaptchaText() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let captcha = '';
  for (let i = 0; i < 4; i++) {
    captcha += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return captcha;
}

// 绘制干扰线
function drawLine(ctx, x1, y1, x2, y2, color) {
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  ctx.stroke();
}

// 生成验证码
function generateCaptcha() {
  const canvas = document.getElementById('captchaCanvas');
  const ctx = canvas.getContext('2d');
  const captchaText = generateCaptchaText();

  // 设置Canvas尺寸
  canvas.width = 130;
  canvas.height = 40;

  // 绘制背景
  ctx.fillStyle = getRandomColor();
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // 绘制干扰线
  for (let i = 0; i < 5; i++) {
    const x1 = Math.random() * canvas.width;
    const y1 = Math.random() * canvas.height;
    const x2 = Math.random() * canvas.width;
    const y2 = Math.random() * canvas.height;
    drawLine(ctx, x1, y1, x2, y2, getRandomColor());
  }

  // 绘制验证码文本
  ctx.font = '20px Arial';
  ctx.fillStyle = '#333';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(captchaText, canvas.width / 2, canvas.height / 2);

  // 将验证码文本设置为表单字段的值
  document.getElementById('captchaInput').setAttribute('data-captcha', captchaText);
}

// 初始化验证码
generateCaptcha();

// 表单提交事件
document.getElementById('authForm').onsubmit = function(event) {
  event.preventDefault();
  const serialInput = document.getElementById("serialNumber").value;
  const passwordInput = document.getElementById("password").value;
  const captchaInput = document.getElementById("captchaInput").value;
  const currentCaptcha = document.getElementById('captchaInput').getAttribute('data-captcha');

  // 这里添加序列号和密码的验证逻辑
  const validSerialNumbers = [
    { serial: "123", password: "123" },
    { serial: "SN456", password: "password456" }
  ];

  let isSerialNumberValid = false;
  let isPasswordValid = false;

  for (let i = 0; i < validSerialNumbers.length; i++) {
    if (validSerialNumbers[i].serial === serialInput && validSerialNumbers[i].password === passwordInput) {
      isSerialNumberValid = true;
      isPasswordValid = true;
      break;
    }
  }

  if (isSerialNumberValid && isPasswordValid && captchaInput === currentCaptcha) {
    alert("验证成功！");
    window.location.href = "../../xz/xz/1.html"; // 跳转到下载页面
  } else {
    alert("序列号、密码或验证码错误，请重试。");
    generateCaptcha(); // 重新生成验证码
  }
};